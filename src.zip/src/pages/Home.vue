<template>
  <!-- preloader
    ================================================== -->
  <div id="preloader" v-if="loading0">
    <div id="loader">
    </div>
  </div>

  <!-- page wrap
    ================================================== -->
  <div id="page" class="s-pagewrap" v-show="!loading0">


    <!-- # site header 
        ================================================== -->
    <header class="s-header">

      <div class="s-header__logo">
        <a class="logo" href="index.html">
          <img src="images/logo.svg" alt="Homepage">
        </a>
      </div>

      <a class="s-header__menu-toggle" href="#0" style="opacity: 10;">
        <span class="s-header__menu-text">Menu</span>
        <span class="s-header__menu-icon"></span>
      </a>

      <nav class="s-header__nav">

        <a href="#0" class="s-header__nav-close-btn" title="close"><span>Close</span></a>
        <h3>{{Vitrine.title}}</h3>

        <ul class="s-header__nav-list">
          <li><a href="#intro" class="smoothscroll">Intro</a></li>
          <li><a href="#about" class="smoothscroll">About</a></li>
          <li><a href="#services" class="smoothscroll">Services</a></li>
          <li><a href="#portfolio" class="smoothscroll">Works</a></li>
          <li><a href="#contact" class="smoothscroll">Contact</a></li>
        </ul>

        <p>


          {{Vitrine.description}} </p>

        <ul class="s-header__social">
          <li>
            <a href="#0">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                style="fill:rgba(0, 0, 0, 1);transform:;-ms-filter:">
                <path
                  d="M20,3H4C3.447,3,3,3.448,3,4v16c0,0.552,0.447,1,1,1h8.615v-6.96h-2.338v-2.725h2.338v-2c0-2.325,1.42-3.592,3.5-3.592 c0.699-0.002,1.399,0.034,2.095,0.107v2.42h-1.435c-1.128,0-1.348,0.538-1.348,1.325v1.735h2.697l-0.35,2.725h-2.348V21H20 c0.553,0,1-0.448,1-1V4C21,3.448,20.553,3,20,3z">
                </path>
              </svg>
              <span class="u-screen-reader-text">Facebook</span>
            </a>
          </li>
          <li>
            <a href="#0">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                style="fill:rgba(0, 0, 0, 1);transform:;-ms-filter:">
                <path
                  d="M19.633,7.997c0.013,0.175,0.013,0.349,0.013,0.523c0,5.325-4.053,11.461-11.46,11.461c-2.282,0-4.402-0.661-6.186-1.809 c0.324,0.037,0.636,0.05,0.973,0.05c1.883,0,3.616-0.636,5.001-1.721c-1.771-0.037-3.255-1.197-3.767-2.793 c0.249,0.037,0.499,0.062,0.761,0.062c0.361,0,0.724-0.05,1.061-0.137c-1.847-0.374-3.23-1.995-3.23-3.953v-0.05 c0.537,0.299,1.16,0.486,1.82,0.511C3.534,9.419,2.823,8.184,2.823,6.787c0-0.748,0.199-1.434,0.548-2.032 c1.983,2.443,4.964,4.04,8.306,4.215c-0.062-0.3-0.1-0.611-0.1-0.923c0-2.22,1.796-4.028,4.028-4.028 c1.16,0,2.207,0.486,2.943,1.272c0.91-0.175,1.782-0.512,2.556-0.973c-0.299,0.935-0.936,1.721-1.771,2.22 c0.811-0.088,1.597-0.312,2.319-0.624C21.104,6.712,20.419,7.423,19.633,7.997z">
                </path>
              </svg>
              <span class="u-screen-reader-text">Twitter</span>
            </a>
          </li>
          <li>
            <a href="#0">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                style="fill:rgba(0, 0, 0, 1);transform:;-ms-filter:">
                <path
                  d="M11.999,7.377c-2.554,0-4.623,2.07-4.623,4.623c0,2.554,2.069,4.624,4.623,4.624c2.552,0,4.623-2.07,4.623-4.624 C16.622,9.447,14.551,7.377,11.999,7.377L11.999,7.377z M11.999,15.004c-1.659,0-3.004-1.345-3.004-3.003 c0-1.659,1.345-3.003,3.004-3.003s3.002,1.344,3.002,3.003C15.001,13.659,13.658,15.004,11.999,15.004L11.999,15.004z">
                </path>
                <circle cx="16.806" cy="7.207" r="1.078"></circle>
                <path
                  d="M20.533,6.111c-0.469-1.209-1.424-2.165-2.633-2.632c-0.699-0.263-1.438-0.404-2.186-0.42 c-0.963-0.042-1.268-0.054-3.71-0.054s-2.755,0-3.71,0.054C7.548,3.074,6.809,3.215,6.11,3.479C4.9,3.946,3.945,4.902,3.477,6.111 c-0.263,0.7-0.404,1.438-0.419,2.186c-0.043,0.962-0.056,1.267-0.056,3.71c0,2.442,0,2.753,0.056,3.71 c0.015,0.748,0.156,1.486,0.419,2.187c0.469,1.208,1.424,2.164,2.634,2.632c0.696,0.272,1.435,0.426,2.185,0.45 c0.963,0.042,1.268,0.055,3.71,0.055s2.755,0,3.71-0.055c0.747-0.015,1.486-0.157,2.186-0.419c1.209-0.469,2.164-1.424,2.633-2.633 c0.263-0.7,0.404-1.438,0.419-2.186c0.043-0.962,0.056-1.267,0.056-3.71s0-2.753-0.056-3.71C20.941,7.57,20.801,6.819,20.533,6.111z M19.315,15.643c-0.007,0.576-0.111,1.147-0.311,1.688c-0.305,0.787-0.926,1.409-1.712,1.711c-0.535,0.199-1.099,0.303-1.67,0.311 c-0.95,0.044-1.218,0.055-3.654,0.055c-2.438,0-2.687,0-3.655-0.055c-0.569-0.007-1.135-0.112-1.669-0.311 c-0.789-0.301-1.414-0.923-1.719-1.711c-0.196-0.534-0.302-1.099-0.311-1.669c-0.043-0.95-0.053-1.218-0.053-3.654 c0-2.437,0-2.686,0.053-3.655c0.007-0.576,0.111-1.146,0.311-1.687c0.305-0.789,0.93-1.41,1.719-1.712 c0.534-0.198,1.1-0.303,1.669-0.311c0.951-0.043,1.218-0.055,3.655-0.055c2.437,0,2.687,0,3.654,0.055 c0.571,0.007,1.135,0.112,1.67,0.311c0.786,0.303,1.407,0.925,1.712,1.712c0.196,0.534,0.302,1.099,0.311,1.669 c0.043,0.951,0.054,1.218,0.054,3.655c0,2.436,0,2.698-0.043,3.654H19.315z">
                </path>
              </svg>
              <span class="u-screen-reader-text">Instagram</span>
            </a>
          </li>
          <li>
            <a href="#0">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;">
                <path
                  d="M20.66 6.98a9.932 9.932 0 0 0-3.641-3.64C15.486 2.447 13.813 2 12 2s-3.486.447-5.02 1.34c-1.533.893-2.747 2.107-3.64 3.64S2 10.187 2 12s.446 3.487 1.34 5.02a9.924 9.924 0 0 0 3.641 3.64C8.514 21.553 10.187 22 12 22s3.486-.447 5.02-1.34a9.932 9.932 0 0 0 3.641-3.64C21.554 15.487 22 13.813 22 12s-.446-3.487-1.34-5.02zM12 3.66c2 0 3.772.64 5.32 1.919-.92 1.174-2.286 2.14-4.1 2.9-1.002-1.813-2.088-3.327-3.261-4.54A7.715 7.715 0 0 1 12 3.66zM5.51 6.8a8.116 8.116 0 0 1 2.711-2.22c1.212 1.201 2.325 2.7 3.34 4.5-2 .6-4.114.9-6.341.9-.573 0-1.006-.013-1.3-.04A8.549 8.549 0 0 1 5.51 6.8zM3.66 12c0-.054.003-.12.01-.2.007-.08.01-.146.01-.2.254.014.641.02 1.161.02 2.666 0 5.146-.367 7.439-1.1.187.373.381.793.58 1.26-1.32.293-2.674 1.006-4.061 2.14S6.4 16.247 5.76 17.5c-1.4-1.587-2.1-3.42-2.1-5.5zM12 20.34c-1.894 0-3.594-.587-5.101-1.759.601-1.187 1.524-2.322 2.771-3.401 1.246-1.08 2.483-1.753 3.71-2.02a29.441 29.441 0 0 1 1.56 6.62 8.166 8.166 0 0 1-2.94.56zm7.08-3.96a8.351 8.351 0 0 1-2.58 2.621c-.24-2.08-.7-4.107-1.379-6.081.932-.066 1.765-.1 2.5-.1.799 0 1.686.034 2.659.1a8.098 8.098 0 0 1-1.2 3.46zm-1.24-5c-1.16 0-2.233.047-3.22.14a27.053 27.053 0 0 0-.68-1.62c2.066-.906 3.532-2.006 4.399-3.3 1.2 1.414 1.854 3.027 1.96 4.84-.812-.04-1.632-.06-2.459-.06z">
                </path>
              </svg>
              <span class="u-screen-reader-text">Dribbble</span>
            </a>
          </li>
          <li>
            <a href="#0">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;">
                <path
                  d="M7.803 5.731c.589 0 1.119.051 1.605.155.483.103.895.273 1.243.508.343.235.611.547.804.939.187.387.28.871.28 1.443 0 .62-.14 1.138-.421 1.551-.283.414-.7.753-1.256 1.015.757.219 1.318.602 1.69 1.146.374.549.557 1.206.557 1.976 0 .625-.119 1.162-.358 1.613a3.11 3.11 0 0 1-.974 1.114 4.315 4.315 0 0 1-1.399.64 6.287 6.287 0 0 1-1.609.206H2V5.731h5.803zm-.351 4.972c.48 0 .878-.114 1.192-.345.312-.228.463-.604.463-1.119 0-.286-.051-.522-.151-.707a1.114 1.114 0 0 0-.417-.428 1.683 1.683 0 0 0-.597-.215 3.609 3.609 0 0 0-.697-.061H4.71v2.875h2.742zm.151 5.239c.267 0 .521-.023.76-.077.241-.052.455-.136.637-.261.182-.12.332-.283.44-.491.109-.206.162-.475.162-.798 0-.634-.179-1.085-.533-1.358-.355-.27-.831-.404-1.414-.404H4.71v3.39h2.893zm8.565-.041c.367.358.896.538 1.584.538.493 0 .919-.125 1.278-.373.354-.249.57-.515.653-.79h2.155c-.346 1.072-.871 1.838-1.589 2.299-.709.463-1.572.693-2.58.693-.702 0-1.334-.113-1.9-.337a4.033 4.033 0 0 1-1.439-.958 4.37 4.37 0 0 1-.905-1.485 5.433 5.433 0 0 1-.32-1.899c0-.666.111-1.289.329-1.864a4.376 4.376 0 0 1 .934-1.493c.405-.42.885-.751 1.444-.994a4.634 4.634 0 0 1 1.858-.362c.754 0 1.413.146 1.979.44a3.967 3.967 0 0 1 1.39 1.182c.363.493.622 1.058.783 1.691.161.632.217 1.292.171 1.983h-6.431c.001.704.238 1.371.606 1.729zm2.812-4.681c-.291-.322-.783-.496-1.385-.496-.391 0-.714.065-.974.199a1.97 1.97 0 0 0-.62.491 1.772 1.772 0 0 0-.328.628 2.82 2.82 0 0 0-.111.587h3.982c-.058-.624-.272-1.085-.564-1.409zm-3.918-4.663h4.989v1.215h-4.989z">
                </path>
              </svg>
              <span class="u-screen-reader-text">Behance</span>
            </a>
          </li>
        </ul>

      </nav>

    </header> <!-- end s-header -->


    <!-- # site-content
        ================================================== -->
    <section id="content" class="s-content">


      <!-- intro
            ----------------------------------------------- -->
      <section id="intro" class="s-intro target-section">

        <div class="s-intro__bg rellax" data-rellax-speed="-5"
          :style=" 'background-image: url(' +Vitrine.header.data[0][1] + ')'"></div>

        <div class="row s-intro__content">

          <div class="column lg-12 s-intro__content-inner">
            <h3 class="s-intro__pretitle"> {{Vitrine.title}}</h3>
            <h1 class="s-intro__title">
              <br>
              {{ parse(Vitrine.description)}}
            </h1>

            <div class="s-intro__more">
              <a class="smoothscroll btn btn--stroke s-intro__more-btn" href="#about">
                Learn More
              </a>
            </div>
          </div> <!-- s-intro__content-inner -->

        </div> <!-- s-intro__content -->

        <ul class="s-intro__social">
          <li>
            <a href="#0">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                style="fill:rgba(0, 0, 0, 1);transform:;-ms-filter:">
                <path
                  d="M20,3H4C3.447,3,3,3.448,3,4v16c0,0.552,0.447,1,1,1h8.615v-6.96h-2.338v-2.725h2.338v-2c0-2.325,1.42-3.592,3.5-3.592 c0.699-0.002,1.399,0.034,2.095,0.107v2.42h-1.435c-1.128,0-1.348,0.538-1.348,1.325v1.735h2.697l-0.35,2.725h-2.348V21H20 c0.553,0,1-0.448,1-1V4C21,3.448,20.553,3,20,3z">
                </path>
              </svg>
              <span class="u-screen-reader-text">Facebook</span>
            </a>
          </li>
          <li>
            <a href="#0">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                style="fill:rgba(0, 0, 0, 1);transform:;-ms-filter:">
                <path
                  d="M19.633,7.997c0.013,0.175,0.013,0.349,0.013,0.523c0,5.325-4.053,11.461-11.46,11.461c-2.282,0-4.402-0.661-6.186-1.809 c0.324,0.037,0.636,0.05,0.973,0.05c1.883,0,3.616-0.636,5.001-1.721c-1.771-0.037-3.255-1.197-3.767-2.793 c0.249,0.037,0.499,0.062,0.761,0.062c0.361,0,0.724-0.05,1.061-0.137c-1.847-0.374-3.23-1.995-3.23-3.953v-0.05 c0.537,0.299,1.16,0.486,1.82,0.511C3.534,9.419,2.823,8.184,2.823,6.787c0-0.748,0.199-1.434,0.548-2.032 c1.983,2.443,4.964,4.04,8.306,4.215c-0.062-0.3-0.1-0.611-0.1-0.923c0-2.22,1.796-4.028,4.028-4.028 c1.16,0,2.207,0.486,2.943,1.272c0.91-0.175,1.782-0.512,2.556-0.973c-0.299,0.935-0.936,1.721-1.771,2.22 c0.811-0.088,1.597-0.312,2.319-0.624C21.104,6.712,20.419,7.423,19.633,7.997z">
                </path>
              </svg>
              <span class="u-screen-reader-text">Twitter</span>
            </a>
          </li>
          <li>
            <a href="#0">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                style="fill:rgba(0, 0, 0, 1);transform:;-ms-filter:">
                <path
                  d="M11.999,7.377c-2.554,0-4.623,2.07-4.623,4.623c0,2.554,2.069,4.624,4.623,4.624c2.552,0,4.623-2.07,4.623-4.624 C16.622,9.447,14.551,7.377,11.999,7.377L11.999,7.377z M11.999,15.004c-1.659,0-3.004-1.345-3.004-3.003 c0-1.659,1.345-3.003,3.004-3.003s3.002,1.344,3.002,3.003C15.001,13.659,13.658,15.004,11.999,15.004L11.999,15.004z">
                </path>
                <circle cx="16.806" cy="7.207" r="1.078"></circle>
                <path
                  d="M20.533,6.111c-0.469-1.209-1.424-2.165-2.633-2.632c-0.699-0.263-1.438-0.404-2.186-0.42 c-0.963-0.042-1.268-0.054-3.71-0.054s-2.755,0-3.71,0.054C7.548,3.074,6.809,3.215,6.11,3.479C4.9,3.946,3.945,4.902,3.477,6.111 c-0.263,0.7-0.404,1.438-0.419,2.186c-0.043,0.962-0.056,1.267-0.056,3.71c0,2.442,0,2.753,0.056,3.71 c0.015,0.748,0.156,1.486,0.419,2.187c0.469,1.208,1.424,2.164,2.634,2.632c0.696,0.272,1.435,0.426,2.185,0.45 c0.963,0.042,1.268,0.055,3.71,0.055s2.755,0,3.71-0.055c0.747-0.015,1.486-0.157,2.186-0.419c1.209-0.469,2.164-1.424,2.633-2.633 c0.263-0.7,0.404-1.438,0.419-2.186c0.043-0.962,0.056-1.267,0.056-3.71s0-2.753-0.056-3.71C20.941,7.57,20.801,6.819,20.533,6.111z M19.315,15.643c-0.007,0.576-0.111,1.147-0.311,1.688c-0.305,0.787-0.926,1.409-1.712,1.711c-0.535,0.199-1.099,0.303-1.67,0.311 c-0.95,0.044-1.218,0.055-3.654,0.055c-2.438,0-2.687,0-3.655-0.055c-0.569-0.007-1.135-0.112-1.669-0.311 c-0.789-0.301-1.414-0.923-1.719-1.711c-0.196-0.534-0.302-1.099-0.311-1.669c-0.043-0.95-0.053-1.218-0.053-3.654 c0-2.437,0-2.686,0.053-3.655c0.007-0.576,0.111-1.146,0.311-1.687c0.305-0.789,0.93-1.41,1.719-1.712 c0.534-0.198,1.1-0.303,1.669-0.311c0.951-0.043,1.218-0.055,3.655-0.055c2.437,0,2.687,0,3.654,0.055 c0.571,0.007,1.135,0.112,1.67,0.311c0.786,0.303,1.407,0.925,1.712,1.712c0.196,0.534,0.302,1.099,0.311,1.669 c0.043,0.951,0.054,1.218,0.054,3.655c0,2.436,0,2.698-0.043,3.654H19.315z">
                </path>
              </svg>
              <span class="u-screen-reader-text">Instagram</span>
            </a>
          </li>
          <li>
            <a href="#0">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;">
                <path
                  d="M20.66 6.98a9.932 9.932 0 0 0-3.641-3.64C15.486 2.447 13.813 2 12 2s-3.486.447-5.02 1.34c-1.533.893-2.747 2.107-3.64 3.64S2 10.187 2 12s.446 3.487 1.34 5.02a9.924 9.924 0 0 0 3.641 3.64C8.514 21.553 10.187 22 12 22s3.486-.447 5.02-1.34a9.932 9.932 0 0 0 3.641-3.64C21.554 15.487 22 13.813 22 12s-.446-3.487-1.34-5.02zM12 3.66c2 0 3.772.64 5.32 1.919-.92 1.174-2.286 2.14-4.1 2.9-1.002-1.813-2.088-3.327-3.261-4.54A7.715 7.715 0 0 1 12 3.66zM5.51 6.8a8.116 8.116 0 0 1 2.711-2.22c1.212 1.201 2.325 2.7 3.34 4.5-2 .6-4.114.9-6.341.9-.573 0-1.006-.013-1.3-.04A8.549 8.549 0 0 1 5.51 6.8zM3.66 12c0-.054.003-.12.01-.2.007-.08.01-.146.01-.2.254.014.641.02 1.161.02 2.666 0 5.146-.367 7.439-1.1.187.373.381.793.58 1.26-1.32.293-2.674 1.006-4.061 2.14S6.4 16.247 5.76 17.5c-1.4-1.587-2.1-3.42-2.1-5.5zM12 20.34c-1.894 0-3.594-.587-5.101-1.759.601-1.187 1.524-2.322 2.771-3.401 1.246-1.08 2.483-1.753 3.71-2.02a29.441 29.441 0 0 1 1.56 6.62 8.166 8.166 0 0 1-2.94.56zm7.08-3.96a8.351 8.351 0 0 1-2.58 2.621c-.24-2.08-.7-4.107-1.379-6.081.932-.066 1.765-.1 2.5-.1.799 0 1.686.034 2.659.1a8.098 8.098 0 0 1-1.2 3.46zm-1.24-5c-1.16 0-2.233.047-3.22.14a27.053 27.053 0 0 0-.68-1.62c2.066-.906 3.532-2.006 4.399-3.3 1.2 1.414 1.854 3.027 1.96 4.84-.812-.04-1.632-.06-2.459-.06z">
                </path>
              </svg>
              <span class="u-screen-reader-text">Dribbble</span>
            </a>
          </li>
          <li>
            <a href="#0">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;">
                <path
                  d="M7.803 5.731c.589 0 1.119.051 1.605.155.483.103.895.273 1.243.508.343.235.611.547.804.939.187.387.28.871.28 1.443 0 .62-.14 1.138-.421 1.551-.283.414-.7.753-1.256 1.015.757.219 1.318.602 1.69 1.146.374.549.557 1.206.557 1.976 0 .625-.119 1.162-.358 1.613a3.11 3.11 0 0 1-.974 1.114 4.315 4.315 0 0 1-1.399.64 6.287 6.287 0 0 1-1.609.206H2V5.731h5.803zm-.351 4.972c.48 0 .878-.114 1.192-.345.312-.228.463-.604.463-1.119 0-.286-.051-.522-.151-.707a1.114 1.114 0 0 0-.417-.428 1.683 1.683 0 0 0-.597-.215 3.609 3.609 0 0 0-.697-.061H4.71v2.875h2.742zm.151 5.239c.267 0 .521-.023.76-.077.241-.052.455-.136.637-.261.182-.12.332-.283.44-.491.109-.206.162-.475.162-.798 0-.634-.179-1.085-.533-1.358-.355-.27-.831-.404-1.414-.404H4.71v3.39h2.893zm8.565-.041c.367.358.896.538 1.584.538.493 0 .919-.125 1.278-.373.354-.249.57-.515.653-.79h2.155c-.346 1.072-.871 1.838-1.589 2.299-.709.463-1.572.693-2.58.693-.702 0-1.334-.113-1.9-.337a4.033 4.033 0 0 1-1.439-.958 4.37 4.37 0 0 1-.905-1.485 5.433 5.433 0 0 1-.32-1.899c0-.666.111-1.289.329-1.864a4.376 4.376 0 0 1 .934-1.493c.405-.42.885-.751 1.444-.994a4.634 4.634 0 0 1 1.858-.362c.754 0 1.413.146 1.979.44a3.967 3.967 0 0 1 1.39 1.182c.363.493.622 1.058.783 1.691.161.632.217 1.292.171 1.983h-6.431c.001.704.238 1.371.606 1.729zm2.812-4.681c-.291-.322-.783-.496-1.385-.496-.391 0-.714.065-.974.199a1.97 1.97 0 0 0-.62.491 1.772 1.772 0 0 0-.328.628 2.82 2.82 0 0 0-.111.587h3.982c-.058-.624-.272-1.085-.564-1.409zm-3.918-4.663h4.989v1.215h-4.989z">
                </path>
              </svg>
              <span class="u-screen-reader-text">Behance</span>
            </a>
          </li>
        </ul> <!-- s-intro__social -->

        <div class="s-intro__scroll">
          <a href="#about" class="smoothscroll">
            <span>Scroll Down</span>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
              style="fill: rgba(0, 0, 0, 1);transform: rotate(180deg);msFilter:progid:DXImageTransform.Microsoft.BasicImage(rotation=2);">
              <path d="M21 11H6.414l5.293-5.293-1.414-1.414L2.586 12l7.707 7.707 1.414-1.414L6.414 13H21z">
              </path>
            </svg>
          </a>
        </div> <!-- s-intro__scroll -->

      </section> <!-- end s-intro -->


      <!-- about
            ----------------------------------------------- -->
      <section id="about" class="s-about target-section" v-if=" Vitrine.aboutUs.status ">

        <div class="row s-about__content" data-animate-block>
          <div class="column lg-12">
            <h2 class="text-pretitle" data-animate-el>About Us</h2>
            <p class="s-about__desc" data-animate-el>
              {{ parse(Vitrine.aboutUs.data[0][1])}}
            </p>
          </div> <!-- end column  -->
        </div> <!-- end s-about__content  -->

      </section> <!-- end about -->


      <!-- services
            ----------------------------------------------- -->
      <section id="services" class="s-services" v-if="Vitrine.service.status">

        <div class="s-services__bg"></div>

        <div class="row narrow section-header section-header--dark has-bottom-sep">
          <div class="column lg-12">

            <h3 class="text-pretitle">Services</h3>
            <h1 class="text-display-title"> {{ parse(Vitrine.service.data[0][1])}}</h1>

            <p class="lead"> {{ parse(Vitrine.service.data[1][1])}}</p>

          </div> <!-- end column -->
        </div> <!-- end section header -->

        <div class="s-services__content">

          <div class="row services-list block-lg-one-half block-tab-whole" data-animate-block>

            <div class="column service-item" data-animate-el>

              <span class="service-icon-block">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                  <path
                    d="M22 4c-1.5 0-2.662 1.685-1.598 3.194.535.759.406 1.216.045 1.749-.765 1.127-1.872 2.057-3.447 2.057-2.521 0-3.854-2.083-4.131-3.848-.096-.614-.15-1.074.436-1.644.402-.39.695-.904.695-1.508 0-1.104-.896-2-2-2s-2 .896-2 2c0 .604.293 1.118.695 1.508.586.57.531 1.03.436 1.644-.277 1.765-1.61 3.848-4.131 3.848-1.575 0-2.682-.93-3.447-2.058-.362-.532-.491-.989.045-1.748 1.064-1.509-.098-3.194-1.598-3.194-1.104 0-2 .896-2 2 0 .797.464 1.495 1.144 1.808.825.38.856 1.317.856 2.171v12.021h20v-12.021c0-.854.031-1.792.856-2.171.68-.313 1.144-1.011 1.144-1.808 0-1.104-.896-2-2-2zm-10 6.297c1.977 2.96 5.58 3.354 8 1.851v3.852h-16v-3.852c2.398 1.49 6.01 1.131 8-1.851zm-8 9.703v-2h16v2h-16z" />
                </svg>
              </span>

              <div class="service-content">
                <h3 class="h4">Branding</h3>

                <p>
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                  accusantium doloremque laudantium, totam rem aperiam, eaque ipsa
                  quae ab illo inventore veritatis et quasi architecto beatae vitae
                  dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas
                  sit aspernatur aut odit aut fugit.
                </p>
              </div>

            </div> <!-- end service-item -->

            <div class="column service-item" data-animate-el>

              <span class="service-icon-block">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                  <path
                    d="M17 8c.552 0 1 .449 1 1s-.448 1-1 1-1-.449-1-1 .448-1 1-1zm0-2c-1.657 0-3 1.343-3 3s1.343 3 3 3 3-1.343 3-3-1.343-3-3-3zm-10 6c-1.657 0-3 1.343-3 3s1.343 3 3 3 3-1.343 3-3-1.343-3-3-3zm10-8c.343 0 .677.035 1 .101v-2.101c0-.552-.447-1-1-1s-1 .448-1 1v2.101c.323-.066.657-.101 1-.101zm-10 6c.343 0 .677.035 1 .101v-8.101c0-.552-.447-1-1-1s-1 .448-1 1v8.101c.323-.066.657-.101 1-.101zm10 4c-.343 0-.677-.035-1-.101v8.101c0 .552.447 1 1 1s1-.448 1-1v-8.101c-.323.066-.657.101-1 .101zm-10 6c-.343 0-.677-.035-1-.101v2.101c0 .552.447 1 1 1s1-.448 1-1v-2.101c-.323.066-.657.101-1 .101z" />
                </svg>
              </span>

              <div class="service-content">
                <h3 class="h4">UI/UX Design</h3>

                <p>
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                  accusantium doloremque laudantium, totam rem aperiam, eaque ipsa
                  quae ab illo inventore veritatis et quasi architecto beatae vitae
                  dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas
                  sit aspernatur aut odit aut fugit.
                </p>
              </div>

            </div> <!-- end service-item -->

            <div class="column service-item" data-animate-el>

              <span class="service-icon-block">
                <svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill-rule="evenodd"
                  clip-rule="evenodd">
                  <path
                    d="M10 16v2.5c0 2.483-2.017 4.5-4.5 4.5-2.484 0-4.5-2.017-4.5-4.5 0-2.484 2.016-4.5 4.5-4.5h2.5v-4h-2.5c-2.484 0-4.5-2.016-4.5-4.5 0-2.483 2.016-4.5 4.5-4.5 2.483 0 4.5 2.017 4.5 4.5v2.5h4v-2.5c0-2.483 2.017-4.5 4.5-4.5 2.484 0 4.5 2.017 4.5 4.5 0 2.484-2.016 4.5-4.5 4.5h-2.5v4h2.5c2.484 0 4.5 2.016 4.5 4.5 0 2.483-2.016 4.5-4.5 4.5-2.483 0-4.5-2.017-4.5-4.5v-2.5h-4zm-2 0h-2.5c-1.379 0-2.5 1.122-2.5 2.5s1.121 2.5 2.5 2.5 2.5-1.122 2.5-2.5v-2.5zm10.5 0h-2.5v2.5c0 1.378 1.121 2.5 2.5 2.5s2.5-1.122 2.5-2.5-1.121-2.5-2.5-2.5zm-4.5-6h-4v4.132h4v-4.132zm-6-2v-2.5c0-1.378-1.121-2.5-2.5-2.5s-2.5 1.122-2.5 2.5 1.121 2.5 2.5 2.5h2.5zm10.5 0c1.379 0 2.5-1.122 2.5-2.5s-1.121-2.5-2.5-2.5-2.5 1.122-2.5 2.5v2.5h2.5z" />
                </svg>
              </span>

              <div class="service-content">
                <h3 class="h4">Web Development</h3>

                <p>
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                  accusantium doloremque laudantium, totam rem aperiam, eaque ipsa
                  quae ab illo inventore veritatis et quasi architecto beatae vitae
                  dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas
                  sit aspernatur aut odit aut fugit.
                </p>
              </div>

            </div> <!-- end service-item -->

            <div class="column service-item" data-animate-el>

              <span class="service-icon-block">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                  <path
                    d="M12 0l-11 6v12.131l11 5.869 11-5.869v-12.066l-11-6.065zm-1 21.2l-6.664-3.555 4.201-2.801c1.08-.719-.066-2.359-1.243-1.575l-4.294 2.862v-7.901l8 4.363v8.607zm-6.867-14.63l6.867-3.746v4.426c0 1.323 2 1.324 2 0v-4.415l6.91 3.811-7.905 4.218-7.872-4.294zm8.867 6.03l8-4.269v7.8l-4.263-2.842c-1.181-.785-2.323.855-1.245 1.574l4.172 2.781-6.664 3.556v-8.6z" />
                </svg>
              </span>

              <div class="service-content">
                <h3 class="h4">Illustration</h3>

                <p>
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                  accusantium doloremque laudantium, totam rem aperiam, eaque ipsa
                  quae ab illo inventore veritatis et quasi architecto beatae vitae
                  dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas
                  sit aspernatur aut odit aut fugit.
                </p>
              </div>

            </div> <!-- end service-item -->

          </div> <!-- end services-list -->

        </div> <!-- end services-content -->

      </section> <!-- end services -->


      <!-- portfolio
            ----------------------------------------------- -->
      <section id="portfolio" class="s-portfolio" v-if="Vitrine.galerie.status">

        <div class="s-portfolio__header">

          <div class="row narrow section-header section-header--dark has-bottom-sep">
            <div class="column lg-12">

              <h3 class="text-pretitle">Showcase</h3>
              <h1 class="text-display-title"> {{ parse(Vitrine.galerie.data[0][1])}}
              </h1>

              <p class="lead">
                {{ parse(Vitrine.galerie.data[1][1])}} </p>

            </div> <!-- end column -->
          </div> <!-- end section header -->

        </div> <!-- end s-portfolio__header -->

        <div class="row s-portfolio__content" data-animate-block>
          <div class="column lg-12">

            <div class="folio-list bricks">


              <div class="brick folio-item" v-for="img in Vitrine.galerie.photo" :key="img.d" data-animate-el>

                <div class="folio-item__thumb">
                  <a class="folio-item__thumb-link" :href="img.src" Title="Salad" data-size="1050x700">
                    <img :src="img.src" :srcset="img.src" alt="">
                  </a>
                </div>
                <div class="folio-item__info">
                  <!-- <div class="folio-item__cat">{{img.title}}</div> -->
                  <h4 class="folio-item__title">{{img.descriptionImage}}</h4>
                </div>
                <a href="https://www.behance.net/" title="Project Link" class="folio-item__project-link">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                    style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;">
                    <path
                      d="M4.222 19.778a4.983 4.983 0 0 0 3.535 1.462 4.986 4.986 0 0 0 3.536-1.462l2.828-2.829-1.414-1.414-2.828 2.829a3.007 3.007 0 0 1-4.243 0 3.005 3.005 0 0 1 0-4.243l2.829-2.828-1.414-1.414-2.829 2.828a5.006 5.006 0 0 0 0 7.071zm15.556-8.485a5.008 5.008 0 0 0 0-7.071 5.006 5.006 0 0 0-7.071 0L9.879 7.051l1.414 1.414 2.828-2.829a3.007 3.007 0 0 1 4.243 0 3.005 3.005 0 0 1 0 4.243l-2.829 2.828 1.414 1.414 2.829-2.828z">
                    </path>
                    <path d="m8.464 16.95-1.415-1.414 8.487-8.486 1.414 1.415z"></path>
                  </svg>
                </a>
                <div class="folio-item__caption">
                  <p>{{img.descriptionImage}}</p>
                </div>

              </div> <!-- end brick-->

            </div> <!-- end folio-list, bricks -->

          </div> <!-- end column  -->
        </div> <!-- end s-portfolio__content -->

        <div class="row testimonials">
          <div class="column lg-12" data-animate-block>

            <h2 class="text-pretitle" data-animate-el>What They Say About Us</h2>

            <div class="swiper-container testimonial-slider" data-animate-el>

              <div class="swiper-wrapper">

                <div class="testimonial-slider__slide swiper-slide">
                  <p>
                    Molestiae incidunt consequatur quis ipsa autem nam sit enim magni. Voluptas
                    tempore rem.
                    Explicabo a quaerat sint autem dolore ducimus ut consequatur neque. Nisi
                    dolores quaerat fuga rem nihil nostrum.
                    Laudantium quia consequatur molestias.
                  </p>
                  <div class="testimonial-slider__author">
                    <img src="images/avatars/user-02.jpg" alt="Author image" class="testimonial-slider__avatar">
                    <cite class="testimonial-slider__cite">
                      <strong>Tim Cook</strong>
                      <span>CEO, Apple</span>
                    </cite>
                  </div>
                </div> <!-- end testimonial-slider__slide -->

                <div class="testimonial-slider__slide swiper-slide">
                  <p>
                    Excepturi nam cupiditate culpa doloremque deleniti repellat. Veniam quos
                    repellat voluptas animi adipisci.
                    Nisi eaque consequatur. Voluptatem dignissimos ut ducimus accusantium
                    perspiciatis.
                    Quasi voluptas eius distinctio. Atque eos maxime.
                  </p>
                  <div class="testimonial-slider__author">
                    <img src="images/avatars/user-03.jpg" alt="Author image" class="testimonial-slider__avatar">
                    <cite class="testimonial-slider__cite">
                      <strong>Sundar Pichai</strong>
                      <span>CEO, Google</span>
                    </cite>
                  </div>
                </div> <!-- end testimonial-slider__slide -->

                <div class="testimonial-slider__slide swiper-slide">
                  <p>
                    Repellat dignissimos libero. Qui sed at corrupti expedita voluptas odit.
                    Nihil ea quia nesciunt. Ducimus aut sed ipsam.
                    Autem eaque officia cum exercitationem sunt voluptatum accusamus. Quasi
                    voluptas eius distinctio.
                    Voluptatem dignissimos ut.
                  </p>
                  <div class="testimonial-slider__author">
                    <img src="images/avatars/user-01.jpg" alt="Author image" class="testimonial-slider__avatar">
                    <cite class="testimonial-slider__cite">
                      <strong>Satya Nadella</strong>
                      <span>CEO, Microsoft</span>
                    </cite>
                  </div>
                </div> <!-- end testimonial-slider__slide -->

                <div class="testimonial-slider__slide swiper-slide">
                  <p>
                    Nunc interdum lacus sit amet orci. Vestibulum dapibus nunc ac augue. Fusce
                    vel dui. In ac felis
                    quis tortor malesuada pretium. Curabitur vestibulum aliquam leo. Qui sed at
                    corrupti expedita voluptas odit.
                    Nihil ea quia nesciunt. Ducimus aut sed ipsam.
                  </p>
                  <div class="testimonial-slider__author">
                    <img src="images/avatars/user-06.jpg" alt="Author image" class="testimonial-slider__avatar">
                    <cite class="testimonial-slider__cite">
                      <strong>Jeff Bezos</strong>
                      <span>CEO, Amazon</span>
                    </cite>
                  </div>
                </div> <!-- end testimonial-slider__slide -->

              </div> <!-- end swiper-wrapper -->

              <div class="swiper-pagination"></div>

            </div> <!-- end swiper-container -->

          </div> <!-- end column -->
        </div> <!-- end row testimonials -->

        <div class="clients-block">
          <div class="row">
            <div class="column lg-12" data-animate-block>

              <div class="swiper-container clients" data-animate-el>
                <div class="swiper-wrapper clients__content">
                  <a href="#0" title="" class="swiper-slide clients__slide"><img
                      src="images/icons/clients/dropbox.svg" /></a>
                  <a href="#0" title="" class="swiper-slide clients__slide"><img
                      src="images/icons/clients/atom.svg" /></a>
                  <a href="#0" title="" class="swiper-slide clients__slide"><img
                      src="images/icons/clients/github.svg" /></a>
                  <a href="#0" title="" class="swiper-slide clients__slide"><img
                      src="images/icons/clients/redhat.svg" /></a>
                  <a href="#0" title="" class="swiper-slide clients__slide"><img
                      src="images/icons/clients/medium.svg" /></a>
                  <a href="#0" title="" class="swiper-slide clients__slide"><img
                      src="images/icons/clients/messenger.svg" /></a>
                  <a href="#0" title="" class="swiper-slide clients__slide"><img
                      src="images/icons/clients/steam.svg" /></a>
                  <a href="#0" title="" class="swiper-slide clients__slide"><img
                      src="images/icons/clients/spotify.svg" /></a>
                </div>

                <div class="swiper-pagination"></div>
              </div> <!-- end clients -->

            </div> <!-- end column -->
          </div> <!-- end clients-outer -->
        </div> <!-- end clients-block -->

      </section> <!-- end portfolio -->

      <!-- contact
            ----------------------------------------------- -->
      <section id="contact" class="s-contact target-section">

        <div class="row section-header section-header--dark">
          <div class="column lg-12">

            <h3 class="text-pretitle">Get In Touch</h3>
            <h1 class="text-display-title">
              Have an idea or an epic project in mind? Talk to us.
              Let’s work together and make something great.
              Drop us a line at <a href="mailto:#0">hello@infinity.com</a>.
            </h1>

          </div> <!-- end column -->
        </div> <!-- end section header -->

        <div class="row s-contact__infos">

          <div class="column lg-5 md-6 stack-on-900 s-contact__block-address">
            <h5 class="with-top-line">Where to Find Us</h5>

            <p>
              1600 Amphitheatre Parkway <br>
              Mountain View, California <br>
              94043 US
            </p>
          </div>

          <div class="column lg-3 md-6 stack-on-900 s-contact__block-social">
            <h5 class="with-top-line">Follow Us</h5>

            <ul class="s-contact__list">
              <li><a href="#0">Facebook</a></li>
              <li><a href="#0">Twitter</a></li>
              <li><a href="#0">Instagram</a></li>
            </ul>
          </div>

          <div class="column lg-4 md-12 stack-on-900 s-contact__block-number">
            <h5 class="with-top-line">Contact Us</h5>

            <ul class="s-contact__list">
              <li><a href="mailto:#0">info@infinity.com</a></li>
              <li><a href="tel:197-543-2345">+197 543 2345</a></li>
              <li><a href="tel:197-123-9876">+197 123 9876</a></li>
            </ul>
          </div>

        </div> <!-- end s-contact__infos -->

        <div class="row s-contact__bottom">

          <div class="column lg-5 tab-12 s-contact__mail-block">
            <a href="mailto:#0" class="btn btn--stroke btn--mail">
              Let's Talk
            </a>
          </div>

          <div class="column lg-7 tab-12 s-contact__subscribe">
            <h5>Subscribe</h5>

            <div class="subscribe-form">
              <form id="mc-form" class="mc-form" novalidate="true">
                <input type="email" name="EMAIL" id="mce-EMAIL" class="u-fullwidth text-center"
                  placeholder="Your Email Address"
                  title="The domain portion of the email address is invalid (the portion after the @)."
                  pattern="^([^\x00-\x20\x22\x28\x29\x2c\x2e\x3a-\x3c\x3e\x40\x5b-\x5d\x7f-\xff]+|\x22([^\x0d\x22\x5c\x80-\xff]|\x5c[\x00-\x7f])*\x22)(\x2e([^\x00-\x20\x22\x28\x29\x2c\x2e\x3a-\x3c\x3e\x40\x5b-\x5d\x7f-\xff]+|\x22([^\x0d\x22\x5c\x80-\xff]|\x5c[\x00-\x7f])*\x22))*\x40([^\x00-\x20\x22\x28\x29\x2c\x2e\x3a-\x3c\x3e\x40\x5b-\x5d\x7f-\xff]+|\x5b([^\x0d\x5b-\x5d\x80-\xff]|\x5c[\x00-\x7f])*\x5d)(\x2e([^\x00-\x20\x22\x28\x29\x2c\x2e\x3a-\x3c\x3e\x40\x5b-\x5d\x7f-\xff]+|\x5b([^\x0d\x5b-\x5d\x80-\xff]|\x5c[\x00-\x7f])*\x5d))*(\.\w{2,})+$"
                  required="">
                <input type="submit" name="subscribe" value="Subscribe" class="btn btn--primary u-fullwidth">
                <!-- <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_cdb7b577e41181934ed6a6a44_9a91cfe7b3" tabindex="-1" value=""></div> -->
                <div class="mc-status"></div>
              </form>
            </div>
          </div>

        </div> <!-- end s-contact__button -->


      </section> <!-- end contact -->

    </section>
    <!-- end s-content -->


    <!-- footer
        ================================================== -->
    <footer id="colophon" class="s-footer">
      <div class="row">
        <div class="column lg-12 ss-copyright">
          <span>© Copyright {{ parse(Vitrine.footer.data[0][1])}}</span>
          <span>Design by <a href="https://www.styleshout.com/">GESSIIA SARL</a></span>
        </div>
      </div>

      <div class="ss-go-top">
        <a class="smoothscroll" title="Back to Top" href="#top">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
            style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;">
            <path d="M6 4h12v2H6zm5 10v6h2v-6h5l-6-6-6 6z"></path>
          </svg>
        </a>
      </div> <!-- end ss-go-top -->
    </footer> <!-- end s-footer -->


  </div> <!-- end s-pagewrap -->


  <!-- photoswipe background
    ================================================== -->
  <div aria-hidden="true" class="pswp" role="dialog" tabindex="-1">

    <div class="pswp__bg"></div>
    <div class="pswp__scroll-wrap">

      <div class="pswp__container">
        <div class="pswp__item"></div>
        <div class="pswp__item"></div>
        <div class="pswp__item"></div>
      </div>

      <div class="pswp__ui pswp__ui--hidden">
        <div class="pswp__top-bar">
          <div class="pswp__counter"></div><button class="pswp__button pswp__button--close"
            title="Close (Esc)"></button> <button class="pswp__button pswp__button--share" title="Share"></button>
          <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button> <button
            class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>
          <div class="pswp__preloader">
            <div class="pswp__preloader__icn">
              <div class="pswp__preloader__cut">
                <div class="pswp__preloader__donut"></div>
              </div>
            </div>
          </div>
        </div>
        <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
          <div class="pswp__share-tooltip"></div>
        </div><button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)"></button>
        <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)"></button>
        <div class="pswp__caption">
          <div class="pswp__caption__center"></div>
        </div>
      </div>

    </div>
  </div>




</template>   
<script> 
import { onMounted, ref } from '@vue/runtime-core'; 
import router from '../boot/routes';

export default {
  name: 'App',
  components: {
    // Header, Footer
  }, 
  beforeCreate() {
    const body = document.getElementsByTagName("body")[0];

    body.classList.remove("bg-gray-100");
    let externalScript = document.createElement('script')
    externalScript.setAttribute('src', 'https://oss.maxcdn.com/respond/1.4.2/respond.min.js')
    document.head.appendChild(externalScript)


    let script = document.createElement('script')
    let script0 = document.createElement('script')

    script0.setAttribute('src', './assets/js/plugins.js')
    script.setAttribute('src', './assets/js/main.js')
    document.head.appendChild(script)
    document.head.appendChild(script0)
  },
 methods:{
  redirect(){
     this.$router.replace({ name: 'invalidVitrine' });

  }
 },
  setup() {

    onMounted(async () => {
      console.log('mounted00000')

      await getVitrineUser();
      console.log('mounted')

    });

    let loading0 = ref(true);
    let Vitrine = ref({
      proprietaire: "Mouafo",
      createur: "Mouafo",
      title: "V0",
      description: "VT40000 DESCRIPTION",
      date: "08/16/2022",
      header: {
        id: 1,
        status: true,
        data: [
          [
            1,
            "image"
          ],
          [
            2,
            ""
          ],
          [
            3,
            ""
          ]
        ]
      },
      aboutUs: {
        id: 2,
        status: true,
        data: [
          [
            1,
            ""
          ],
          [
            2,
            ""
          ],
        ]
      },
      service: {
        id: 3,
        status: true,
        data: [
          [
            5,
            ""
          ],
          [
            12,
            ""
          ]
        ]
      },
      galerie: {
        id: 4,
        status: true,
        data: [
          [
            6,
            ""
          ],
          [
            13,
            ""
          ]
        ]
      },
      temoignage: {
        id: 5,
        status: false,
        data: [
          [
            7,
            ""
          ]
        ]
      },
      footer: {
        id: 6,
        status: true,
        data: [
          [
            8,
            "GESSIIA"
          ],
          [
            9,
            "GESSIIA SARL"
          ]
        ]
      }
    });

    // xhr.="Access-Control-Allow-Origin: *"
    function makeRequest(method, url, data) {

      let xhr = new XMLHttpRequest();

      return new Promise(function (resolve, reject) {

        xhr.open(method, 'http://127.0.0.1:8000' + url, true);
        xhr.responseType = "json";

        xhr.send(JSON.stringify(data));


        xhr.onload = function () {

          if (this.status >= 200 && this.status < 300) {
            resolve(xhr.response);

          } else {

            router.push({ name: 'invalidVitrine' });

            reject({
              status: this.status,
              statusText: xhr.statusText
            });

          }
        };

        xhr.onerror = function () {
          // aff('corr')
          // aff(xhr)
          router.push({ name: 'invalidVitrine' });

          reject({
            status: this.status,
            statusText: xhr.statusText
          });
        

        };



      });

    }
    function isHTML(str) {
      var a = document.createElement('div');
      a.innerHTML = str;

      for (var c = a.childNodes, i = c.length; i--;) {
        if (c[i].nodeType == 1) return true;
      }

      return false;
    }
    const parse = (data) => {
      if (isHTML(data)) {
        console.log('data', data)
        var parser = new window.DOMParser();
        let parsee = parser.parseFromString(data, 'text/html').body.firstChild.innerHTML
        if (isHTML(parsee)) {
          console.log('ddsd')
          return parse(parsee);
        }
        return parsee;
      }
      else {
        return data
      }


    }
    const getVitrineUser = async () => {
      const queryString = window.location.search;
      console.log(queryString);
      const urlParams = new URLSearchParams(queryString);
      const vitrine = urlParams.get('vitrine')
      console.log(vitrine);
      var data = {
        vitrine: window.location.pathname.split('/')[
                  window.location.pathname.split('/').length - 1
                ]
      }
      const contain = await makeRequest("POST", '/vitrine/user', data);

      loading0.value = !loading0.value
      console.log(contain);
      let script = document.createElement('script')
      let script0 = document.createElement('script')

      script0.setAttribute('src', 'assets/js/plugins.js')
      script.setAttribute('src', 'assets/js/main.js')
      document.head.appendChild(script)
      document.head.appendChild(script0)
      Vitrine.value = contain;

      console.log(Vitrine.value)
    };



    return {
      Vitrine, loading0, parse

    };
  },

}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50; 
}
</style>
