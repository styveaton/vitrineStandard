export class ApiManage {
  


      // baseUrl = 'http://192.168.100.4:8000';
 baseUrl = 'http://www.api.devoo.gessiia.com';


}